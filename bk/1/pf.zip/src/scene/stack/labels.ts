/** @module scene/stack/labels: pins each layer-nav button to its slab's right face via getLayerRect. @see docs/MOTION.md (Pick, hover, touch), src/scene/stack/pick.ts */
import { LAYERS } from '@/config/layers';
import { getLayerRect } from '../api';

export interface LabelParts {
  buttons: HTMLButtonElement[];
  update(): void;
}

export function initLabels(): LabelParts {
  const nav = document.querySelector<HTMLElement>('.layer-nav');
  const buttons = [...document.querySelectorAll<HTMLButtonElement>('.layer-nav button')];
  if (!nav || buttons.length === 0) {
    return { buttons, update: () => undefined };
  }

  // Buttons become absolutely positioned children of the sticky stage,
  // one per slab, following its right face every frame.
  nav.style.position = 'static';
  for (const li of nav.querySelectorAll('li')) {
    (li as HTMLElement).style.display = 'contents';
  }
  for (const btn of buttons) {
    btn.style.position = 'absolute';
    btn.style.left = '0';
    btn.style.top = '0';
    btn.style.willChange = 'transform';
  }

  return {
    buttons,
    update() {
      for (let i = 0; i < buttons.length && i < LAYERS.length; i++) {
        const rect = getLayerRect(LAYERS[i].id);
        if (!rect) continue;
        // Anchor: the projected right-face center; offset the pill to its right.
        const x = rect.left + 20;
        const y = rect.top - 18;
        buttons[i].style.transform = `translate(${Math.round(x)}px, ${Math.round(y)}px)`;
      }
    },
  };
}
